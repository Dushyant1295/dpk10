<?php declare(strict_types=1);

namespace WP_Rocket\Dependencies\League\Container\Argument;

interface ClassNameInterface
{
    /**
     * Return the class name.
     *
     * @return string
     */
    public function getClassName() : string;
}
